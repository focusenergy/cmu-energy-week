# Load forecasting test harness

This package simulates real-time load forecasting
test data, and facilitates testing with known data-availability
constraints.

## Installation

To install the package, run 

`python setup.py install`

within the top-level directory of the package source.